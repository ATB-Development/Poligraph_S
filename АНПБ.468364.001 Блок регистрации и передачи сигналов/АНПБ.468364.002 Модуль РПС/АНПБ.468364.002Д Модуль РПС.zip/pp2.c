/*----------------------------------
  Без кнопки, но с переключателем
  Генерация клока для АЦП таймером T0
----------------------------------*/


#include "pp2.h"

CDC_Line_Coding_t LineEncoding = { .BaudRateBPS = 230400,
                                   .CharFormat  = OneStopBit,
                                   .ParityType  = Parity_None,
                                   .DataBits    = 8            };

#define SAMPLEN		18
#define CLOCK0		8000000
#define PRESC1		8
#define PRESC0		1024
#define FREQ1A		50
#define P_OCR1A		((CLOCK0 - 2*PRESC1*FREQ1A)/2/PRESC1/FREQ1A)
#define P_OCR1AH	(P_OCR1A >> 8)
#define P_OCR1AL	(P_OCR1A & 0xFF)
#define P_TCCR1A	0x00
#define P_TCCR1B	0x0A

#define P_TCCR0A	0x42
#define P_TCCR0B	0x81
#define P_OCR0A		0

#define LEDMASK_USB_WAIT	0x40
#define LEDMASK_USB_WORK	0x10
#define LEDMASK_BLU_WAIT	0x50
#define LEDMASK_BLU_WORK	0x14

static uint8_t ledmask_usb = LEDMASK_USB_WAIT;
static uint8_t ledmask_blu = LEDMASK_BLU_WAIT;
static uint8_t sample[SAMPLEN];
static int8_t cflag = 0;
static int8_t sflag = 0;
static int8_t btflag = 0;

static uint8_t ticks = 0;
static uint8_t ct_l = 0;
static uint8_t ct_h = 0;

inline void LED_on(void);
inline void LED_off(void);
inline void LED_toggle(void);
static void SPI_AD7739_Init(void);
static void IO_Init(void);
void USART_Init(void);
void USART_Send(unsigned char data);
unsigned char USART_Get(void);
void USART_Send_Array(unsigned char *data, int n);
static void SPI_Transmit(unsigned char data);
static unsigned char SPI_Receive(void);
static void Conv8(unsigned char mode);
static void StartConv(void);
static void StopConv(void);
static void choose(uint8_t c);
static void analog_on(void);
static void analog_off(void);
static inline void bt_on(void);
static inline void bt_off(void);
#ifdef NEED_SLEEP
static void sleep_prepare(void);
#endif

ISR(TIMER0_COMPA_vect)
{
//	PORTD ^= _BV(PD5);
}

ISR(TIMER1_COMPA_vect)
{
	++ticks;
	if (++ct_l == 0) {
		++ct_h;
	}

/*	if (!cflag) {
		if ((PIND & _BV(PD0))) {
			if (button_pr)
				++button_cnt;
			else
				button_pr = 1;
		}
		else {
			if (button_pr) {
				if (button_cnt > 100) {
					sleep_prepare();
					sleep_cpu();
					sleep_disable();
				}
				else if (button_cnt > 3) {
					ct_h = 0;
					if (btflag)
						bt_off();
					else
						bt_on();
					btflag = ~btflag;
				}
			}
			button_pr = 0;
			button_cnt = 0;
		}
	}
	else {
		ct_h = 0;*/
	if (cflag)
		PORTC |= _BV(PC4);
/*	}*/
}

ISR(INT6_vect)		// RDY
{
	ct_h = 0;
	sei();
	if (cflag) {
		PORTC &= ~_BV(PC4);
		if (sflag) {
			Conv8(0x81);
			cflag = sflag = 0;
		}
		else
			Conv8(0x00);
	}
	PORTD ^= _BV(PD5);
}

int main(void)
{
	SetupHardware();
	USART_Init();
	StopConv();
	cflag = sflag = 0;
	sei();
	if ((PIND & _BV(PD0))) {
		bt_off();
		btflag = 0;
	}
	else {
		bt_on();
		btflag = -1;
	}

	for (;;) {
#ifdef NEED_SLEEP
		if (ct_h > 240) {	// 5 min
			goto sleep_out;
		}
#endif
		if (btflag) {
			if ((UCSR1A & (1 << RXC1))) {
				choose(UDR1);
			}
			if (!(ticks & ledmask_blu))
				PORTD |= _BV(PD4);
			else
				PORTD &= ~_BV(PD4);
		}
		else {
			if ((ticks & ledmask_usb))
				PORTD |= _BV(PD4);
			else
				PORTD &= ~_BV(PD4);
			CDC_Task();
			USB_USBTask();
		}
	}
#ifdef NEED_SLEEP
sleep_out:
	sleep_prepare();
	sleep_cpu();
	sleep_disable();
#endif
}

/** Configures the board hardware and chip peripherals for the demo's functionality. */
void SetupHardware(void)
{
	/* Disable watchdog if enabled by bootloader/fuses */
	DDRD |= _BV(PD4);
	MCUSR &= ~(1 << WDRF);
	wdt_disable();

	/* Disable clock division */
	clock_prescale_set(clock_div_1);

#ifdef NEED_SLEEP
	/* Disable Sleep */
	cli();
	USBCON &= ~_BV(FRZCLK);
	PRR0 &= ~0x2C;
//	PRR1 &= ~0x81;
	set_sleep_mode(SLEEP_MODE_PWR_DOWN);
	SREG &= ~0x80;
	REGCR &= ~1;
	sleep_disable();
	PCICR &= ~2;
	PCMSK1 &= ~8;
	sei();
#endif
	/* Hardware Initialization */
	USB_Init();

	SPI_AD7739_Init();
	IO_Init();
}

/** Event handler for the USB_Connect event. This indicates that the device is enumerating via the status LEDs and
 *  starts the library USB task to begin the enumeration and USB management process.
 */
void EVENT_USB_Device_Connect(void)
{
}

/** Event handler for the USB_Disconnect event. This indicates that the device is no longer connected to a host via
 *  the status LEDs and stops the USB management and CDC management tasks.
 */
void EVENT_USB_Device_Disconnect(void)
{
}

/** Event handler for the USB_ConfigurationChanged event. This is fired when the host set the current configuration
 *  of the USB device after enumeration - the device endpoints are configured and the CDC management task started.
 */
void EVENT_USB_Device_ConfigurationChanged(void)
{
	/* Setup CDC Notification, Rx and Tx Endpoints */
	if (!(Endpoint_ConfigureEndpoint(CDC_NOTIFICATION_EPNUM, EP_TYPE_INTERRUPT,
		                             ENDPOINT_DIR_IN, CDC_NOTIFICATION_EPSIZE,
	                                 ENDPOINT_BANK_SINGLE)))
	{
	}
	
	if (!(Endpoint_ConfigureEndpoint(CDC_TX_EPNUM, EP_TYPE_BULK,
		                             ENDPOINT_DIR_IN, CDC_TXRX_EPSIZE,
	                                 ENDPOINT_BANK_SINGLE)))
	{
	}
	
	if (!(Endpoint_ConfigureEndpoint(CDC_RX_EPNUM, EP_TYPE_BULK,
		                             ENDPOINT_DIR_OUT, CDC_TXRX_EPSIZE,
	                                 ENDPOINT_BANK_SINGLE)))
	{
	}
	
	/* Reset line encoding baud rate so that the host knows to send new values */
	LineEncoding.BaudRateBPS = 0;
}

/** Event handler for the USB_UnhandledControlRequest event. This is used to catch standard and class specific
 *  control requests that are not handled internally by the USB library (including the CDC control commands,
 *  which are all issued via the control endpoint), so that they can be handled appropriately for the application.
 */
void EVENT_USB_Device_UnhandledControlRequest(void)
{
	/* Process CDC specific control requests */
	switch (USB_ControlRequest.bRequest)
	{
		case REQ_GetLineEncoding:
			if (USB_ControlRequest.bmRequestType == (REQDIR_DEVICETOHOST | REQTYPE_CLASS | REQREC_INTERFACE))
			{	
				/* Acknowledge the SETUP packet, ready for data transfer */
				Endpoint_ClearSETUP();

				/* Write the line coding data to the control endpoint */
				Endpoint_Write_Control_Stream_LE(&LineEncoding, sizeof(CDC_Line_Coding_t));
				
				/* Finalize the stream transfer to send the last packet or clear the host abort */
				Endpoint_ClearOUT();
			}
			
			break;
		case REQ_SetLineEncoding:
			if (USB_ControlRequest.bmRequestType == (REQDIR_HOSTTODEVICE | REQTYPE_CLASS | REQREC_INTERFACE))
			{
				/* Acknowledge the SETUP packet, ready for data transfer */
				Endpoint_ClearSETUP();

				/* Read the line coding data in from the host into the global struct */
				Endpoint_Read_Control_Stream_LE(&LineEncoding, sizeof(CDC_Line_Coding_t));

				/* Finalize the stream transfer to clear the last packet from the host */
				Endpoint_ClearIN();
			}
	
			break;
		case REQ_SetControlLineState:
			if (USB_ControlRequest.bmRequestType == (REQDIR_HOSTTODEVICE | REQTYPE_CLASS | REQREC_INTERFACE))
			{
				/* Acknowledge the SETUP packet, ready for data transfer */
				Endpoint_ClearSETUP();
				
				/* NOTE: Here you can read in the line state mask from the host, to get the current state of the output handshake
				         lines. The mask is read in from the wValue parameter in USB_ControlRequest, and can be masked against the
						 CONTROL_LINE_OUT_* masks to determine the RTS and DTR line states using the following code:
				*/
				
				Endpoint_ClearStatusStage();
			}
	
			break;
	}
}

/** Function to manage CDC data transmission and reception to and from the host. */
void CDC_Task(void)
{
//	char*       ReportString    = NULL;
//	static bool ActionSent      = false;
	static uint8_t c;
//	char s[] = "I am here!";

	/* Device must be connected and configured for the task to run */
	if (USB_DeviceState != DEVICE_STATE_Configured)
	  return;
	  
#if 0
	/* NOTE: Here you can use the notification endpoint to send back line state changes to the host, for the special RS-232
	 *       handshake signal lines (and some error states), via the CONTROL_LINE_IN_* masks and the following code:
	 */
	USB_Notification_Header_t Notification = (USB_Notification_Header_t)
		{
			.NotificationType = (REQDIR_DEVICETOHOST | REQTYPE_CLASS | REQREC_INTERFACE),
			.Notification     = NOTIF_SerialState,
			.wValue           = 0,
			.wIndex           = 0,
			.wLength          = sizeof(uint16_t),
		};
		
	uint16_t LineStateMask;
	
	// Set LineStateMask here to a mask of CONTROL_LINE_IN_* masks to set the input handshake line states to send to the host
	
	Endpoint_SelectEndpoint(CDC_NOTIFICATION_EPNUM);
	Endpoint_Write_Stream_LE(&Notification, sizeof(Notification));
	Endpoint_Write_Stream_LE(&LineStateMask, sizeof(LineStateMask));
	Endpoint_ClearIN();
#endif

	/* Flag management - Only allow one string to be sent per action */
#if 0
	if ((ReportString != NULL) && (ActionSent == false) && LineEncoding.BaudRateBPS)
	{
		/* Select the Serial Tx Endpoint */
		Endpoint_SelectEndpoint(CDC_TX_EPNUM);

		/* Write the String to the Endpoint */
		Endpoint_Write_Stream_LE(ReportString, strlen(ReportString));
		
		/* Remember if the packet to send completely fills the endpoint */
		bool IsFull = (Endpoint_BytesInEndpoint() == CDC_TXRX_EPSIZE);

		/* Finalize the stream transfer to send the last packet */
		Endpoint_ClearIN();

		/* If the last packet filled the endpoint, send an empty packet to release the buffer on 
		 * the receiver (otherwise all data will be cached until a non-full packet is received) */
		if (IsFull)
		{
			/* Wait until the endpoint is ready for another packet */
			Endpoint_WaitUntilReady();
			
			/* Send an empty packet to ensure that the host does not buffer data sent to it */
			Endpoint_ClearIN();
		}
	}

	/* Select the Serial Rx Endpoint */
	Endpoint_SelectEndpoint(CDC_RX_EPNUM);
	
	/* Throw away any received data from the host */
	if (Endpoint_IsOUTReceived())
	  Endpoint_ClearOUT();
#endif

	Endpoint_SelectEndpoint(CDC_RX_EPNUM);
	if (Endpoint_IsOUTReceived()) {
		c = Endpoint_Read_Byte();
		choose(c);
		Endpoint_ClearOUT();
//		if (c == 0xaa) {
//			EIMSK |= 4;
//			sleep_cpu();
//		}
//		if (c == d)
//			Endpoint_SelectEndpoint(CDC_TX_EPNUM);
//			Endpoint_Write_Byte(c);
//			Endpoint_ClearIN();
//			PORTD ^= _BV(PD4);
	}
//	Endpoint_SelectEndpoint(CDC_TX_EPNUM);
//	Endpoint_Write_Byte(d);
//	Endpoint_ClearIN();
}

inline void LED_on(void)
{
	PORTD |= _BV(PD4);
}

inline void LED_off(void)
{
	PORTD &= ~_BV(PD4);
}

inline void LED_toggle(void)
{
	PORTD ^= _BV(PD4);
}

//**********************************
// Настройка USART
//**********************************
void USART_Init(void)
{
	UBRR1L = 8;					// 115200
	UCSR1A = 1 << U2X1;				// double
	UCSR1B = (1 << TXEN1) | (1 << RXEN1);
	UCSR1C = (1 << UCSZ10) | (1 << UCSZ11);		// sz 8
}

//**********************************
// Настройка SPI и управления AD7739
//**********************************
void SPI_AD7739_Init(void)
{
	volatile unsigned char t;
	char i;

/*
PB0 --> ~CS (AD7739) - ставим в 1
PB1 --> SCK (AD7739)
PB2 --> MOSI (SPI)
PB3 <-- MISO (SPI)
PB6 --> ~RESET - ставим в 1
PC4 --> SYNC (AD7739)
PD6 <-- ~RDY (AD7739) (INT6)
*/
	DDRB |= _BV(PB0) | _BV(PB1) | _BV(PB2) | _BV(PB6);
	PORTB |= _BV(PB0) | _BV(PB6);
	DDRC |= _BV(PC4);

	EICRB |= _BV(ISC61); // Настройка прерывания INT6 - падающий фронт
	EIMSK |= _BV(INT6);   // Разрешение INT6

/*
Настройка SPI master
--------------------
SPSR:
    SPI2X - двойная скорость
*/
	SPSR |= _BV(SPI2X);
/*
SPCR:
    SPE - разрешение SPI
    MSTR - SPI - мастер
    SPR0 - 1 -> Fosc/8 с учетом SPI2X=1
    CPHA - фаза клока - по второму фронту
    CPOL - полярность клока - отрицательная
*/
	SPCR = _BV(SPE) | _BV(MSTR) | _BV(CPHA) | _BV(CPOL) | _BV(SPR0);
	t = SPCR; // Так
	t = SPDR; // в инструкции
/* Теперь настраиваем вход SYNC AD7739 */
	SPI_Transmit(0x41);
	t = SPI_Receive();
	t |= 9; /* Вкл RDYFN и SYNC */
	SPI_Transmit(0x01);
	SPI_Transmit(t);
/* Разрешаем все каналы для непрерывного преобразования
   7-й канал - для батарейки */
	for (i=0; i<7; i++) {
		SPI_Transmit(0x68 + i);
		t = SPI_Receive();
		t |= 8;
		SPI_Transmit(0x28 + i);
		SPI_Transmit(t);
	}
	t |= 4;
	SPI_Transmit(0x28 + 7);
	SPI_Transmit(t);
/* Настраиваем время преобразования каналов
   CHOP = 1
   CT (uS) = (FW*128+263)/MCLK (MHz) для одного канала
   Выбираем FW = 4, т.е. Channel Conversion Time Reg. = 0x84
   При этом CT = 1682 uS для 8 каналов - вроде бы устраивает.
*/

	for (i=0x30; i<0x38; i++) {
		SPI_Transmit(i);
		SPI_Transmit(0x84);
	}
}

//********************************
// Настройка портов и таймеров
//********************************
void IO_Init(void)
{
/*
	PB4 --> BT_ON
	PB5 --> AN_ON
	PB7 --> OC0A - генератор clock для АЦП
	PC2 <-- KN
	PC5,PC6,PC7 --> 0 пустые
	PD0 <-- KN
	PD1 <-- Power_OK ( 0 - заряд )
	PD4 --> LED
	PD5 --> UPR ( коммутатор реографа )
*/
	DDRB |= _BV(PB4) | _BV(PB5) | _BV(PB7);
	DDRC |= _BV(PC5) | _BV(PC6) | _BV(PC7);
//	DDRC &= ~_BV(PC2);
	PORTB &= ~_BV(PB7);
	PORTC &= ~(_BV(PC5) | _BV(PC6) | _BV(PC7));
	DDRD |= _BV(PD4) | _BV(PD5);
	DDRD &= ~_BV(PD0);

	OCR1AH = P_OCR1AH;
	OCR1AL = P_OCR1AL;
	TCCR1A = P_TCCR1A;
	TCCR1B = P_TCCR1B;
	TIMSK1 |= _BV(OCIE1A);

	TCCR0A = 0;
	TCCR0B = 0;
	TIMSK0 = 0;
	OCR0A = P_OCR0A;
}

//********************************
// Передача байта по USART
//********************************
void USART_Send(unsigned char data)
{
	while (!(UCSR1A & (1 << UDRE1))) ;
	UDR1 = data;
}

//********************************
// Прием байта по USART
//********************************
unsigned char USART_Get(void)
{
	for (;;) {
		if ((ticks & 0x80))
			PORTD |= _BV(PD4);
		else
			PORTD &= ~_BV(PD4);
		if ((UCSR1A & (1 << RXC1)))
			break;
	}

	return UDR1;
}

//********************************
// Передача массива по USART
//********************************
void USART_Send_Array(unsigned char *data, int n)
{
	int i;

	for (i=0; i<n; i++)
		USART_Send(data[i]);
}

//********************************
// Передача байта по SPI Master
//********************************
void SPI_Transmit(unsigned char data)
{
    PORTB &= ~_BV(PB0);
    SPDR = data;
    while (!(SPSR & (1<<SPIF))) ;
    PORTB |= _BV(PB0);
}

//***************************
// Прием по SPI
//***************************
unsigned char SPI_Receive(void)
{
    PORTB &= ~_BV(PB0);
    SPDR = 0;
    while (!(SPSR & (1<<SPIF))) ;
    PORTB |= _BV(PB0);
    return (unsigned char)SPDR;
}

void StartConv(void)
{
	SPI_Transmit(0x38);
	SPI_Transmit(0x21);
}
void StopConv(void)
{
	SPI_Transmit(0x38);
	SPI_Transmit(0x00);
}

void Conv8(unsigned char mode)
{
	char i;
	unsigned char *ps = sample;
	unsigned char vl, vh;
	bool IsFull;

	*ps++ = mode;
	*ps++ = mode;
	for (i=0; i<8; i++) {
		SPI_Transmit(0x48+i);
		vl = SPI_Receive();
		vh = SPI_Receive();
		if (!vl & !vh)
			++vl;
		*ps++ = vl;
		*ps++ = vh;
	}
	if (!btflag) {
		Endpoint_SelectEndpoint(CDC_TX_EPNUM);
		Endpoint_Write_Stream_LE(sample, 18);
		IsFull = (Endpoint_BytesInEndpoint() == CDC_TXRX_EPSIZE);
		Endpoint_ClearIN();
		if (IsFull) {
			Endpoint_WaitUntilReady();
			Endpoint_ClearIN();
		}
	}
	else
		USART_Send_Array(sample, 18);
}

void analog_on(void)
{
	PORTB |= _BV(PB5);
	_delay_loop_2(60500);
	TCCR0A = P_TCCR0A;
	TCCR0B = P_TCCR0B;
}

void analog_off(void)
{
	PORTB &= ~_BV(PB5);
	TCCR0B = 0;
	TCCR0A = 0;
	PORTB &= ~_BV(PB7);
}

inline void bt_on(void)
{
	PORTB |= _BV(PB4);
}

inline void bt_off(void)
{
	PORTB &= ~_BV(PB4);
}

void choose(uint8_t c)
{
		ct_h = 0;
		switch (c) {
			case 0x80:
				if (cflag)
					break;
				ledmask_usb = LEDMASK_USB_WORK;
				ledmask_blu = LEDMASK_BLU_WORK;
				analog_on();
				StartConv();
				cflag = 1;
				break;
			case 0x10:
				ledmask_usb = LEDMASK_USB_WAIT;
				ledmask_blu = LEDMASK_BLU_WAIT;
				analog_off();
				cflag = 0;
				sei();
				break;
			case 0x81:
				analog_on();
				StartConv();
				cflag = sflag = 1;
				analog_off();
				break;
			case 0x90:
				if (!cflag)
					analog_off();
				break;
			case 0x91:
				analog_on();
				break;
//			case 0xD0:
//				OCR0A = OCR0_50;
//				break;
//			case 0xD4:
//				OCR0A = OCR0_70;
//				break;
//			case 0xD8:
//				OCR0A = OCR0_200;
//				break;
			case 0xE1:
				LED_on();
				break;
			case 0xE0:
				LED_off();
				break;
			case 0xE2:
				LED_toggle();
				break;
			case 0xF0:
				if (!btflag) {
					Endpoint_SelectEndpoint(CDC_TX_EPNUM);
					Endpoint_Write_Byte(0x38);
					Endpoint_ClearIN();
				}
				else
					USART_Send(0x38);
				break;
			default:
				break;
		}
}

#ifdef NEED_SLEEP
void sleep_prepare(void)
{
	LED_off();
	cli();
	USBCON |= _BV(FRZCLK);
	UCSR1A = 0;
	UCSR1B = 0;
	UCSR1C = 0;
	SPCR &= ~_BV(SPE);
	PCICR |= 2;
	PCMSK1 |= 8;
	SREG |= 0x80;
	REGCR |= 1;
	PORTB &= ~(_BV(PB0) | _BV(PB1) | _BV(PB6));
	PRR0 = 0x2C;
//	PRR1 = 0x81;
	set_sleep_mode(SLEEP_MODE_PWR_DOWN);
	sleep_enable();
	sei();
}
#endif
